FLAG CLASH ARENA — ANDROID PROJECT

The original uploaded game is bundled as app/src/main/assets/index.html and loaded locally
inside a full-screen Android WebView. Gameplay JavaScript, flag roster, physics, sounds,
elimination sequence and winner celebration are preserved.

BUILD AN APK
1. Install Android Studio on a computer.
2. Open this folder (the folder containing settings.gradle.kts) in Android Studio.
3. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio creates the APK at:
   app/build/outputs/apk/debug/app-debug.apk

For a shareable release APK, use Build > Generate Signed Bundle / APK and create a keystore.

Requirements: Android Studio with JDK 17 and Android SDK Platform 35.
Application ID: com.flagclash.arena
Minimum Android: 6.0 (API 23)
